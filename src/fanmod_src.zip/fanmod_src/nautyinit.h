#ifndef NAUTY_H
#define NAUTY_H

#define MAXN 64

extern "C" {
   #include "nauty/nauty.h"
   #include "nauty/nautinv.h"
   //#include "nauty/gtools.h"
}

#endif
